from interface import start_interface

def main():
    print("Bienvenue dans Atherome App – Voyage Onirique")
    start_interface()

if __name__ == "__main__":
    main()
