Atherome App – Voyage Onirique
------------------------------

Lancez le programme avec `python main.py`.
Commencez le voyage onirique et faites vos choix ternaires.
Athena et Morgana vous guideront.
Toutes vos décisions sont enregistrées dans la base de données SQLite.
Feedback thérapeutique disponible après chaque choix.

Modules inclus :
- main.py
- interface.py
- voyage.py
- entites.py
- base_donnees.py
- therapeutique.py
- setup.py
- assets/ (images, sons, animations)
