import sqlite3

conn = sqlite3.connect('sessions.db')
c = conn.cursor()
c.execute('''
    CREATE TABLE IF NOT EXISTS voyage (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        choice TEXT
    )
''')
conn.commit()

def save_session(choice):
    c.execute('INSERT INTO voyage (choice) VALUES (?)', (choice,))
    conn.commit()
