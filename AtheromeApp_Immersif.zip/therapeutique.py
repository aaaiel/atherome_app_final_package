def analyze_choices(choice):
    if choice == "Oui":
        print("Vous avez choisi le chemin actif. Continuez à explorer.")
    elif choice == "Non":
        print("Vous avez choisi la prudence. Observez et réfléchissez.")
    else:
        print("Indécision ou observation… Un chemin subtil se dévoile.")
