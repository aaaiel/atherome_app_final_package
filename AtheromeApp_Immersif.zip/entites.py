class Athena:
    def __init__(self):
        self.name = "Athena"

    def dialogue(self):
        return "Je suis Athena, votre guide. Choisissez avec sagesse."

class Morgana:
    def __init__(self):
        self.name = "Morgana"

    def dialogue(self):
        return "Je suis Morgana. Parfois les chemins que vous évitez sont les plus révélateurs."
