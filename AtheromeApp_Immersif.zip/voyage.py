import tkinter as tk
from entites import Athena, Morgana
from base_donnees import save_session
from therapeutique import analyze_choices

CHOIX_TERNAIRE = ["Oui", "Non", "Indéfini"]

def start_voyage(root):
    voyage_window = tk.Toplevel(root)
    voyage_window.title("Voyage Onirique")
    voyage_window.geometry("800x600")

    scene_label = tk.Label(voyage_window, text="Vous entrez dans un monde onirique…", font=("Helvetica", 16))
    scene_label.pack(pady=20)

    def make_choice(choice):
        save_session(choice)
        analyze_choices(choice)
        next_scene_label.config(text=f"Vous avez choisi : {choice}. La suite du voyage continue…")

    buttons_frame = tk.Frame(voyage_window)
    buttons_frame.pack(pady=20)

    for c in CHOIX_TERNAIRE:
        b = tk.Button(buttons_frame, text=c, command=lambda ch=c: make_choice(ch))
        b.pack(side="left", padx=5)

    next_scene_label = tk.Label(voyage_window, text="")
    next_scene_label.pack(pady=20)
