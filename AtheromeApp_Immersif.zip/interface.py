import tkinter as tk
from voyage import start_voyage

def start_interface():
    root = tk.Tk()
    root.title("Atherome App – Voyage Onirique")
    root.geometry("800x600")

    def launch_voyage():
        start_voyage(root)

    title = tk.Label(root, text="Atherome App", font=("Helvetica", 24))
    title.pack(pady=20)

    start_button = tk.Button(root, text="Commencer le Voyage Onirique", command=launch_voyage)
    start_button.pack(pady=10)

    root.mainloop()
