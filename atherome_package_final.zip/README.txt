====================================================
             ATHÉROME - README TECHNIQUE
====================================================

Nom de code   : Atheris
Version       : 1.0.0 (Démo)
Type          : Application Electron (multiplateforme)
Fonction      : Copilote IA expérimental pour gestion 
                et analyse de données (civiles, 
                médicales, scientifiques, stratégiques)

----------------------------------------------------
1. OBJECTIF
----------------------------------------------------
Athérome est une application conçue pour :
- Collecter et traiter des informations.
- Fournir une interface simple et rapide.
- Explorer les usages de l’IA dans le domaine 
  scientifique, médical et militaire.
- Tester un mécanisme d’auto-update (Electron-Updater).

----------------------------------------------------
2. ARCHITECTURE
----------------------------------------------------
- Frontend : HTML / CSS / JavaScript
- Backend  : Node.js / Express
- Core     : Electron
- Auto-Update : GitHub Releases + Electron-Updater

----------------------------------------------------
3. INSTALLATION
----------------------------------------------------
1. Télécharger le package ZIP.
2. Décompresser dans un dossier de travail.
3. Installer Node.js (LTS).
4. Dans le terminal, exécuter :
   > cd Atheris_AutoUpdate_Full_Package
   > npm install
   > npm run build
5. Le fichier setup.exe se trouve dans /dist.

----------------------------------------------------
4. UTILISATION
----------------------------------------------------
- Lancer l’application depuis le raccourci ou via 
  le fichier exécutable.
- Interface simple : saisie d’une requête et affichage
  de la réponse traitée par le backend.
- Les mises à jour sont appliquées automatiquement
  lors des nouvelles versions.

----------------------------------------------------
5. SECURITÉ
----------------------------------------------------
- Données locales isolées par utilisateur.
- HTTPS recommandé pour les déploiements distants.
- Version démo = aucune collecte sensible.

----------------------------------------------------
6. NOTES
----------------------------------------------------
Ce projet est une base expérimentale, destinée à 
évoluer vers :
- Intégration d’un portefeuille crypto.
- Connexion à une IA pour traitement automatique.
- Applications thérapeutiques et militaires.

====================================================
