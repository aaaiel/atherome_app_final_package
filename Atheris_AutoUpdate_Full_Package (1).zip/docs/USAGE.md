# Atheris AutoUpdate Demo

## Run locally
```bash
npm install
npm start
```

## Build installer
```bash
npm run dist
```

Artifacts will be in `dist/`.

## GitHub Actions
Tag a release (`git tag v1.0.0 && git push origin v1.0.0`) and GitHub Actions will
build and upload installers.

## Notes
- Requires GH_TOKEN secret for publishing.
- Electron Builder handles code signing (configure if needed).
