# Renderer integration

In your frontend code, listen for update events from preload.js.

```js
window.electronAPI.onUpdateAvailable(() => {
  alert("Update available, downloading...");
});

window.electronAPI.onUpdateDownloaded(() => {
  if (confirm("Update downloaded. Restart now?")) {
    // will trigger autoUpdater.quitAndInstall
  }
});
```
