#!/bin/bash
# Script de packaging Atherome App
echo "Build Atherome App" 